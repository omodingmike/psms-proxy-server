<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Esp32Controller extends Controller
{
    function post(Request $request)
    {
        info($request);
        $data = Arr::dot($request->fields);
        $bloodPressure = $data['bloodPressure.integerValue'];
        $pulseRate = $data['pulseRate.integerValue'];
        $temperature = $data['temperature.doubleValue'];

        $post_data = [
            'fields' => [
                'bloodPressure' => [
                    'integerValue' => $bloodPressure
                ],
                'pulseRate' => [
                    'integerValue' => $pulseRate
                ],
                'temperature' => [
                    'doubleValue' => $temperature
                ],
                'date' => [
                    'integerValue' => time()
                ],
            ]
        ];

        $client = new Client();
        $headers = [
            'Content-Type' => 'application/json'
        ];

        $post_url = 'https://firestore.googleapis.com/v1/projects/psms-9efd8/databases/(default)/documents/records';
        $post_url2 = 'https://students.sol-uganda.org/api/check';

        try {
            return $client->request('POST', $post_url, [
                'headers' => $headers,
                'body' => json_encode($post_data)
            ]);
        } catch (GuzzleException $e) {
            info($e->getMessage());
        }

    }
}
